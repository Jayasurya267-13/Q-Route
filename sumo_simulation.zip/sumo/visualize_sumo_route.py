import sys
sys.path.insert(0, "/home/claude/qroutex_bench")
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.lines as mlines
import sumolib

from sumo_instance import build_instance_from_sumo, load_edge_congestion, build_real_graph
from algorithms import run_qpso
from vrp_core import solution_metrics, two_opt, route_cost

NET_FILE = "network.net.xml"
DEPOT = "C2"
rng = np.random.default_rng(11)
all_nodes = ['A0','A1','A2','A3','A4','A5','B0','B1','B2','B3','B4','B5',
             'C0','C1','C2','C3','C4','C5','D0','D1','D2','D3','D4','D5',
             'E0','E1','E2','E3','E4','E5','F0','F1','F2','F3','F4','F5']
CUSTOMERS = list(rng.choice([n for n in all_nodes if n != DEPOT], size=15, replace=False))

inst = build_instance_from_sumo(DEPOT, CUSTOMERS, capacity=45)
fit, routes, curve = run_qpso(inst, 30, 150, seed=1001)
routes = [two_opt(r, inst, "W", max_passes=3) for r in routes]
dist, time_, cong = solution_metrics(routes, inst)
print(f"QPSO (real SUMO instance) best fitness={fit:.2f}, after 2-opt: "
      f"dist={dist:.1f} time={time_:.1f} cong={cong:.2f}")

net = sumolib.net.readNet(NET_FILE)
edge_congestion = load_edge_congestion()

fig, ax = plt.subplots(figsize=(10, 9))

# Draw every real road edge, colored by REAL measured congestion (speedRelative)
for edge in net.getEdges():
    shape = edge.getShape()
    xs, ys = zip(*shape)
    speed_rel = edge_congestion.get(edge.getID(), {}).get("speed_relative", 1.0)
    # lower speed_relative = more congested -> redder
    congestion_level = 1.0 - speed_rel
    color = plt.cm.RdYlGn(1.0 - min(1.0, max(0.0, congestion_level * 2.2)))
    ax.plot(xs, ys, color=color, linewidth=2.2, alpha=0.85, zorder=1)

# Overlay the optimized fleet route
node_ids = inst["node_ids"]
route_colors = ["#0F6E56", "#993C1D", "#BA7517", "#185FA5", "#534AB7"]
G = build_real_graph(NET_FILE, edge_congestion)
for vi, route in enumerate(routes):
    full_path_nodes = [0] + route + [0]
    color = route_colors[vi % len(route_colors)]
    for a, b in zip(full_path_nodes[:-1], full_path_nodes[1:]):
        na, nb = node_ids[a], node_ids[b]
        try:
            import networkx as nx
            path = nx.shortest_path(G, na, nb, weight="time_real")
            for u, v in zip(path[:-1], path[1:]):
                edge_id = G[u][v]["edge_id"]
                e = net.getEdge(edge_id)
                xs, ys = zip(*e.getShape())
                ax.plot(xs, ys, color=color, linewidth=4.5, alpha=0.9, zorder=3,
                         solid_capstyle="round")
        except Exception:
            pass

# Mark depot and customers
for i, nid in enumerate(node_ids):
    x, y = net.getNode(nid).getCoord()
    if i == 0:
        ax.scatter([x], [y], s=260, marker="D", color="#1E2761", zorder=5,
                   edgecolors="white", linewidths=1.5)
        ax.annotate("Depot", (x, y), textcoords="offset points", xytext=(0, 14),
                    ha="center", fontsize=10, fontweight="bold", color="#1E2761")
    else:
        ax.scatter([x], [y], s=170, color="#CADCFC", zorder=5,
                   edgecolors="#1E2761", linewidths=1.3)
        ax.annotate(str(i), (x, y), ha="center", va="center", fontsize=8,
                    fontweight="bold", color="#1E2761", zorder=6)

legend_handles = [
    mlines.Line2D([], [], color=plt.cm.RdYlGn(0.9), linewidth=3, label="Light real traffic"),
    mlines.Line2D([], [], color=plt.cm.RdYlGn(0.1), linewidth=3, label="Heavy real traffic (citizens)"),
]
for vi, route in enumerate(routes):
    legend_handles.append(mlines.Line2D([], [], color=route_colors[vi % len(route_colors)],
                                         linewidth=4, label=f"Vehicle {vi+1} route"))
ax.legend(handles=legend_handles, loc="lower right", fontsize=9, framealpha=0.9)

ax.set_title("QRouteX optimized fleet routes on a real SUMO network\n"
              "Background color = real congestion from ~1,440 simulated citizen trips",
              fontsize=12, fontweight="bold")
ax.set_aspect("equal")
ax.axis("off")
plt.tight_layout()
plt.savefig("/home/claude/qroutex_sumo/sumo_route_visualization.png", dpi=150, bbox_inches="tight")
print("Saved visualization")
