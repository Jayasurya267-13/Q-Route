"""
Builds a QRouteX VRP instance from REAL SUMO simulation output, instead of
the synthetic random congestion used in vrp_core.generate_instance().

Pipeline:
  1. Parse edge_congestion.xml -- real per-edge speed, travel time, and
     vehicle counts produced by simulating background citizen traffic
     (background_traffic.rou.xml, ~1440 trips over 1 simulated hour).
  2. Build a real road graph (networkx) from the SUMO network, with each
     edge weighted by its REAL measured congested travel time.
  3. Pick depot + customer junctions from the actual grid network.
  4. Compute real shortest-path distance/time/congestion between every
     pair of selected junctions (Dijkstra over the real network -- not
     Euclidean straight-line distance).
  5. Return an `inst` dict with the exact same shape vrp_core.py's
     generate_instance() produces, so run_qpso/run_pso/run_ga work
     completely unchanged.
"""
import xml.etree.ElementTree as ET
import numpy as np
import networkx as nx
import sumolib

NET_FILE = "network.net.xml"
EDGEDATA_FILE = "edge_congestion.xml"


def load_edge_congestion(path=EDGEDATA_FILE):
    """Parse SUMO's real edge-level measurements from the background
    traffic simulation. speedRelative = observed_speed / free_flow_speed,
    so 1.0 = free flowing, lower = more congested."""
    tree = ET.parse(path)
    root = tree.getroot()
    edge_data = {}
    for interval in root.findall("interval"):
        for edge in interval.findall("edge"):
            eid = edge.get("id")
            edge_data[eid] = {
                "traveltime": float(edge.get("traveltime", 0)) or None,
                "speed": float(edge.get("speed", 0)) or None,
                "speed_relative": float(edge.get("speedRelative", 1.0)),
                "vehicles_entered": int(edge.get("entered", 0)),
                "vehicles_departed": int(edge.get("departed", 0)),
                "sampled_seconds": float(edge.get("sampledSeconds", 0)),
            }
    return edge_data


def build_real_graph(net_file=NET_FILE, edge_congestion=None):
    """networkx graph of the real SUMO network. Edge weight 'time_real' is
    the REAL measured congested travel time (falls back to free-flow time
    for edges with zero simulated traffic -- no background trips happened
    to use them in this particular random-trip run)."""
    net = sumolib.net.readNet(net_file)
    G = nx.DiGraph()

    for node in net.getNodes():
        x, y = node.getCoord()
        G.add_node(node.getID(), x=x, y=y)

    for edge in net.getEdges():
        eid = edge.getID()
        length = edge.getLength()
        speed_limit = edge.getSpeed()
        free_flow_time = length / speed_limit if speed_limit > 0 else length

        measured = edge_congestion.get(eid, {}) if edge_congestion else {}
        real_time = measured.get("traveltime") or free_flow_time
        speed_rel = measured.get("speed_relative", 1.0)
        vehicles = measured.get("vehicles_entered", 0)

        G.add_edge(
            edge.getFromNode().getID(), edge.getToNode().getID(),
            edge_id=eid, length=length, free_flow_time=free_flow_time,
            time_real=real_time, speed_relative=speed_rel, vehicles=vehicles,
        )
    return G


def build_instance_from_sumo(depot_id, customer_ids, capacity, demand_seed=42,
                              net_file=NET_FILE, edgedata_file=EDGEDATA_FILE):
    """Produces the same inst dict shape as vrp_core.generate_instance(),
    but every distance/time/congestion value is derived from the REAL
    simulated network and REAL background traffic -- not synthetic."""
    edge_congestion = load_edge_congestion(edgedata_file)
    G = build_real_graph(net_file, edge_congestion)

    node_ids = [depot_id] + list(customer_ids)
    n = len(customer_ids)

    coords = np.array([[G.nodes[nid]["x"], G.nodes[nid]["y"]] for nid in node_ids])

    dist = np.zeros((n + 1, n + 1))
    time_mat = np.zeros((n + 1, n + 1))
    cong = np.zeros((n + 1, n + 1))
    real_vehicle_counts = np.zeros((n + 1, n + 1))  # for reporting: real citizen traffic on the path

    for i, a in enumerate(node_ids):
        for j, b in enumerate(node_ids):
            if i == j:
                continue
            try:
                path_edges = nx.shortest_path(G, a, b, weight="time_real")
                total_len, total_time, total_free, total_vehicles = 0.0, 0.0, 0.0, 0
                for u, v in zip(path_edges[:-1], path_edges[1:]):
                    e = G[u][v]
                    total_len += e["length"]
                    total_time += e["time_real"]
                    total_free += e["free_flow_time"]
                    total_vehicles += e["vehicles"]
                dist[i, j] = total_len
                time_mat[i, j] = total_time
                cong[i, j] = total_time / total_free if total_free > 0 else 1.0
                real_vehicle_counts[i, j] = total_vehicles
            except nx.NetworkXNoPath:
                dist[i, j] = time_mat[i, j] = 1e6
                cong[i, j] = 1.0

    ALPHA, BETA, GAMMA = 0.35, 0.45, 0.20
    W = ALPHA * dist + BETA * time_mat + GAMMA * cong

    rng = np.random.default_rng(demand_seed)
    demands = rng.integers(3, 11, size=n + 1).astype(float)
    demands[0] = 0.0
    total_demand = demands.sum()
    n_vehicles = max(2, int(np.ceil(total_demand * 1.2 / capacity)))

    return {
        "n": n, "n_vehicles": n_vehicles, "capacity": capacity,
        "coords": coords, "demands": demands,
        "dist": dist, "time": time_mat, "congestion": cong, "W": W,
        "node_ids": node_ids, "real_vehicle_counts": real_vehicle_counts,
    }
