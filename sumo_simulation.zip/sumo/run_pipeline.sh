#!/bin/bash
# QRouteX + SUMO end-to-end pipeline.
# Regenerates everything from scratch: real road network, real background
# citizen traffic simulation, real measured congestion. Requires SUMO
# installed (apt install sumo sumo-tools) and SUMO_HOME set.
set -e
export SUMO_HOME=${SUMO_HOME:-/usr/share/sumo}

echo "[1/5] Generating a 6x6 grid road network (36 junctions, 120 real edges)..."
netgenerate --grid --grid.number=6 --grid.length=250 --grid.attach-length=0 \
  -o network.net.xml --no-turnarounds

echo "[2/5] Generating background citizen traffic demand (~1440 trips over 1 simulated hour)..."
python3 "$SUMO_HOME/tools/randomTrips.py" -n network.net.xml -o background_trips.trips.xml \
  --begin 0 --end 3600 --period 2.5 --seed 7 --fringe-factor 5

echo "[3/5] Routing background trips through the real network..."
duarouter -n network.net.xml -t background_trips.trips.xml \
  -o background_traffic.rou.xml --ignore-errors

echo "[4/5] Running the SUMO simulation and measuring real per-edge congestion..."
sumo -n network.net.xml -r background_traffic.rou.xml -a edgedata.add.xml \
  --begin 0 --end 3600 --no-step-log --duration-log.disable true

echo "[5/5] Building a QRouteX instance from real SUMO data and running QPSO..."
python3 visualize_sumo_route.py

echo "Done. See sumo_route_visualization.png for the result."
