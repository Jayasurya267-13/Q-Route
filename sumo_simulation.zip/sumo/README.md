# QRouteX + SUMO background-traffic simulation

This closes the honesty gap flagged earlier: congestion is no longer a
random number. It's measured from an actual SUMO traffic simulation.

## What changed

| Before | Now |
|---|---|
| `congestion_ij` = random number, 0.8-1.6 | `congestion_ij` = real speedRelative measured from SUMO |
| Distance = Euclidean straight-line | Distance = real shortest path over a real road network |
| No concept of "how many citizens use this route" | Real vehicle counts (`entered`/`departed`) per edge, from ~1,440 simulated background trips |
| Coordinates = random points | Coordinates = real junctions on a 6x6 grid network |

## Pipeline (run_pipeline.sh runs all of this)

1. **`netgenerate`** builds a real 6x6 grid road network -- 36 junctions,
   120 edges, each with a real length and speed limit.
2. **`randomTrips.py`** generates ~1,440 background trips over a simulated
   hour -- these represent ordinary citizen traffic, not your delivery fleet.
3. **`duarouter`** computes real routes for every background trip through
   the network.
4. **`sumo`** runs the actual simulation. As background vehicles move and
   interact, real congestion emerges -- roads with more simultaneous
   traffic get measurably slower. This is captured per edge in
   `edge_congestion.xml`: `speedRelative` (observed speed / free-flow
   speed), `entered`/`departed` (real vehicle counts -- literally "how
   many citizens used this route" in the simulated hour).
5. **`sumo_instance.py`** builds a QRouteX `inst` dict from this real data:
   picks a depot + customer junctions, computes real shortest-path
   distance/time/congestion between every pair using the measured
   `speedRelative` values, and produces the exact same dict shape
   `vrp_core.generate_instance()` does -- so `run_qpso`/`run_pso`/`run_ga`
   work completely unchanged.
6. **`visualize_sumo_route.py`** runs QPSO + 2-opt on this real instance
   and renders the result: real road colors by real measured congestion,
   with the optimized fleet routes overlaid.

## Honest limitations still remaining

- **Delivery demand is still synthetic** (random 3-10 units per customer).
  This is legitimately business data (order volume), not traffic data --
  it should come from your logistics company's actual order system, not
  from a traffic simulator. SUMO can't help with this part.
- **Background trip generation is randomized**, not calibrated to any real
  city's actual traffic patterns (rush hour timing, real origin-destination
  demand). A production system would calibrate this against real traffic
  counts or GPS probe data for the target city.
- **The network is a synthetic 6x6 grid**, not a real city's street layout.
  Swapping `netgenerate` for `osmnx`-derived real OSM road data would fix
  this without changing anything downstream.
- **This does not yet model the "many fleets/system-optimal" problem**
  discussed earlier (multiple optimizers all routing onto the same road).
  It measures real congestion from background traffic and reacts to it --
  it doesn't yet account for how the fleet's own routing choices would, at
  scale, change that congestion.

## To extend with a real city

Replace step 1 (`netgenerate`) with:
```python
import osmnx as ox
G = ox.graph_from_place("Chennai, India", network_type="drive")
ox.save_graphml(G, "chennai.graphml")
# convert to a SUMO network with netconvert --osm-files
```
Everything downstream (background traffic, congestion measurement,
QRouteX instance building) works unchanged.

## Files

- `run_pipeline.sh` -- regenerates everything from scratch
- `network.net.xml` -- the real road network (SUMO format)
- `background_trips.trips.xml`, `background_traffic.rou.xml` -- citizen traffic demand and routes
- `edgedata.add.xml`, `edge_congestion.xml` -- congestion measurement config and real results
- `sumo_instance.py` -- bridges real SUMO data into a QRouteX instance
- `visualize_sumo_route.py` -- runs QPSO and renders the final map
- `vrp_core.py`, `algorithms.py` -- the same validated QRouteX core used everywhere else
- `sumo_route_visualization.png` -- the rendered output
